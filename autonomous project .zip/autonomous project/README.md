# Autonomous Systems Project: Visual-Inertial SLAM with Fiducial Landmark Anchors

Welcome to the **Visual-Inertial SLAM with Fiducial Landmark Anchors** repository.

The complete codebase for **Milestone 1** is located in the [`IE415_SLAM`](./IE415_SLAM/) folder.

## Quick Start (Windows PowerShell)

```powershell
# Navigate into the project folder
cd IE415_SLAM

# Set up virtual environment
python -m venv venv
.\venv\Scripts\Activate.ps1

# Install requirements
pip install -r requirements.txt

# Step 1: Generate ArUco markers (IDs 0-9)
python generate_markers.py

# Step 2: Create a sample synthetic video for instant offline testing
python create_sample_video.py

# Step 3: Run the detection pipeline on the video
python detect_markers.py --input data/sample_aruco_video.mp4

# Step 4: Run automated verification tests
python -m unittest tests/test_pipeline.py -v
```

See the detailed documentation:
- [IE415_SLAM README](./IE415_SLAM/README.md)
- [Milestone 1 Technical Report](./IE415_SLAM/docs/milestone_1.md)

