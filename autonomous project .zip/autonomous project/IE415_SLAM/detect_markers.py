"""
==============================================================================
IE415: Visual-Inertial SLAM with Fiducial Landmark Anchors
Milestone 1: Laptop-Based Video Loading and ArUco Marker Detection Pipeline
Module: detect_markers.py
==============================================================================

Description:
    Processes input video files or live webcam streams to detect ArUco fiducial
    markers. For every frame:
      1. Detects markers from the DICT_4X4_50 dictionary using OpenCV's
         modern ArUco API (cv2.aruco.ArucoDetector).
      2. Extracts all 4 corner coordinates (x, y) for each visible marker.
      3. Renders visual annotations (bounding box, corner orientation, ID, HUD).
      4. Logs every detected marker observation to a structured CSV file.
      5. Encodes and exports the annotated video to an MP4 file.
      6. Prints comprehensive summary statistics upon completion.

Usage:
    # Process a recorded video file
    python detect_markers.py --input data/test_video.mp4

    # Run in live webcam mode (default camera index 0)
    python detect_markers.py --webcam 0

    # Headless mode (no display window, useful for scripts/servers)
    python detect_markers.py --input data/test_video.mp4 --no-display

    # Custom output paths
    python detect_markers.py --input data/test_video.mp4 --csv_output results/custom.csv --video_output results/custom.mp4
==============================================================================
"""

import argparse
import csv
import sys
import time
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple, Union

try:
    import cv2
    import numpy as np
except ImportError as err:
    print(f"\n[ERROR] Required dependency missing: {err}")
    print("Please install requirements using:")
    print("    pip install -r requirements.txt\n")
    sys.exit(1)


# Dictionary mappings
ARUCO_DICTIONARY_MAP = {
    "DICT_4X4_50": cv2.aruco.DICT_4X4_50,
    "DICT_4X4_100": cv2.aruco.DICT_4X4_100,
    "DICT_4X4_250": cv2.aruco.DICT_4X4_250,
    "DICT_4X4_1000": cv2.aruco.DICT_4X4_1000,
    "DICT_5X5_50": cv2.aruco.DICT_5X5_50,
    "DICT_5X5_100": cv2.aruco.DICT_5X5_100,
    "DICT_6X6_50": cv2.aruco.DICT_6X6_50,
    "DICT_6X6_250": cv2.aruco.DICT_6X6_250,
}

# CSV columns specification according to Milestone 1 requirements
CSV_COLUMNS = [
    "frame_number",
    "timestamp_seconds",
    "marker_id",
    "corner_1_x",
    "corner_1_y",
    "corner_2_x",
    "corner_2_y",
    "corner_3_x",
    "corner_3_y",
    "corner_4_x",
    "corner_4_y",
]


def init_aruco_detector(dict_name: str = "DICT_4X4_50"):
    """
    Initialize OpenCV ArUco detector using the modern OpenCV 4.7+ API
    (cv2.aruco.ArucoDetector) with safe fallback to legacy API if needed.

    Args:
        dict_name: Name of predefined ArUco dictionary.

    Returns:
        tuple (detector_or_none, dictionary, detector_parameters)
    """
    if dict_name not in ARUCO_DICTIONARY_MAP:
        raise ValueError(f"Unknown dictionary '{dict_name}'.")

    dict_id = ARUCO_DICTIONARY_MAP[dict_name]

    # Get dictionary object
    if hasattr(cv2.aruco, "getPredefinedDictionary"):
        dictionary = cv2.aruco.getPredefinedDictionary(dict_id)
    elif hasattr(cv2.aruco, "Dictionary_get"):
        dictionary = cv2.aruco.Dictionary_get(dict_id)
    else:
        raise RuntimeError("Cannot load ArUco dictionary with installed OpenCV version.")

    # Configure detector parameters
    if hasattr(cv2.aruco, "DetectorParameters"):
        detector_params = cv2.aruco.DetectorParameters()
    elif hasattr(cv2.aruco, "DetectorParameters_create"):
        detector_params = cv2.aruco.DetectorParameters_create()
    else:
        detector_params = None

    # Modern OpenCV 4.7+ Detector API
    detector = None
    if hasattr(cv2.aruco, "ArucoDetector"):
        detector = cv2.aruco.ArucoDetector(dictionary, detector_params)

    return detector, dictionary, detector_params


def detect_markers_in_frame(
    frame: np.ndarray,
    detector: Any,
    dictionary: Any,
    detector_params: Any,
) -> Tuple[List[np.ndarray], Optional[np.ndarray]]:
    """
    Detect ArUco markers in an individual BGR or grayscale image frame.

    Args:
        frame: BGR or grayscale image array.
        detector: cv2.aruco.ArucoDetector instance (if available).
        dictionary: cv2.aruco dictionary instance.
        detector_params: cv2.aruco.DetectorParameters instance.

    Returns:
        corners: List of numpy arrays, each of shape (1, 4, 2) or (4, 2).
        ids: 2D array of detected integer IDs (e.g. shape (N, 1)) or None.
    """
    if frame is None or frame.size == 0:
        return [], None

    # Use modern ArucoDetector if available
    if detector is not None:
        corners, ids, _rejected = detector.detectMarkers(frame)
    else:
        # Legacy OpenCV 4.x fallback
        corners, ids, _rejected = cv2.aruco.detectMarkers(
            frame, dictionary, parameters=detector_params
        )

    return corners, ids


def extract_marker_observations(
    frame_number: int,
    timestamp_seconds: float,
    corners: List[np.ndarray],
    ids: Optional[np.ndarray],
) -> List[Dict[str, Union[int, float]]]:
    """
    Format detected marker corners into standardized observation dictionary rows.

    Corner ordering in OpenCV ArUco:
      - Corner 1: Top-Left
      - Corner 2: Top-Right
      - Corner 3: Bottom-Right
      - Corner 4: Bottom-Left

    Args:
        frame_number: Current frame index (0-indexed).
        timestamp_seconds: Elapsed video timestamp in seconds.
        corners: List of detected marker corners.
        ids: Array of detected marker IDs.

    Returns:
        List of dicts, each matching the CSV_COLUMNS schema.
    """
    observations: List[Dict[str, Union[int, float]]] = []

    if ids is None or len(ids) == 0:
        return observations

    for i in range(len(ids)):
        marker_id = int(ids[i][0]) if hasattr(ids[i], "__len__") else int(ids[i])
        marker_corners = corners[i]

        # Handle shape (1, 4, 2) or (4, 2)
        if marker_corners.ndim == 3 and marker_corners.shape[0] == 1:
            pts = marker_corners[0]
        else:
            pts = marker_corners

        row: Dict[str, Union[int, float]] = {
            "frame_number": int(frame_number),
            "timestamp_seconds": round(float(timestamp_seconds), 4),
            "marker_id": marker_id,
            "corner_1_x": round(float(pts[0][0]), 2),
            "corner_1_y": round(float(pts[0][1]), 2),
            "corner_2_x": round(float(pts[1][0]), 2),
            "corner_2_y": round(float(pts[1][1]), 2),
            "corner_3_x": round(float(pts[2][0]), 2),
            "corner_3_y": round(float(pts[2][1]), 2),
            "corner_4_x": round(float(pts[3][0]), 2),
            "corner_4_y": round(float(pts[3][1]), 2),
        }
        observations.append(row)

    return observations


def render_annotations(
    frame: np.ndarray,
    corners: List[np.ndarray],
    ids: Optional[np.ndarray],
    frame_number: int,
    timestamp_seconds: float,
    fps: float,
) -> np.ndarray:
    """
    Draw marker boundaries, corner indicators, ID badges, and HUD overlay on frame.

    Args:
        frame: BGR frame to annotate.
        corners: Detected corner arrays.
        ids: Detected IDs array.
        frame_number: Current frame index.
        timestamp_seconds: Elapsed timestamp.
        fps: Video frames per second.

    Returns:
        Annotated copy of the frame.
    """
    annotated = frame.copy()

    # Draw native ArUco markers with boundaries and IDs
    if ids is not None and len(ids) > 0:
        cv2.aruco.drawDetectedMarkers(annotated, corners, ids)

        # Highlight Corner 1 (Top-Left) with a distinct colored circle for orientation
        for i in range(len(ids)):
            marker_corners = corners[i]
            pts = marker_corners[0] if marker_corners.ndim == 3 else marker_corners
            c1_x, c1_y = int(round(pts[0][0])), int(round(pts[0][1]))
            # Red circle on top-left corner indicates origin for 3D pose in Milestone 2
            cv2.circle(annotated, (c1_x, c1_y), 4, (0, 0, 255), -1, cv2.LINE_AA)

    # Render a modern, professional Heads-Up Display (HUD) banner at top
    h, w = annotated.shape[:2]
    hud_h = 42
    overlay = annotated.copy()
    cv2.rectangle(overlay, (0, 0), (w, hud_h), (20, 20, 20), -1)
    # Blend semi-transparent background
    cv2.addWeighted(overlay, 0.65, annotated, 0.35, 0, annotated)

    detected_count = len(ids) if ids is not None else 0
    id_list_str = str(sorted([int(i[0]) for i in ids])) if detected_count > 0 else "None"

    hud_text_left = f"Frame: {frame_number} | Time: {timestamp_seconds:6.2f}s | FPS: {fps:.1f}"
    hud_text_right = f"Markers ({detected_count}): {id_list_str}"

    font = cv2.FONT_HERSHEY_SIMPLEX
    font_scale = 0.52
    thickness = 1
    cv2.putText(
        annotated,
        hud_text_left,
        (12, 26),
        font,
        font_scale,
        (255, 255, 255),
        thickness,
        cv2.LINE_AA,
    )
    cv2.putText(
        annotated,
        hud_text_right,
        (w - 420 if w > 600 else 12, 26 if w > 600 else 38),
        font,
        font_scale,
        (50, 220, 100) if detected_count > 0 else (180, 180, 180),
        thickness,
        cv2.LINE_AA,
    )

    return annotated


def initialize_video_writer(
    output_path: Path,
    fps: float,
    width: int,
    height: int,
) -> Optional[cv2.VideoWriter]:
    """
    Attempt to initialize an OpenCV VideoWriter with fallback codecs.

    Args:
        output_path: Path to target MP4 video file.
        fps: Frames per second.
        width: Frame width in pixels.
        height: Frame height in pixels.

    Returns:
        cv2.VideoWriter instance or None if all attempts fail.
    """
    output_path.parent.mkdir(parents=True, exist_ok=True)

    # List of common Windows-compatible codecs in priority order
    codecs_to_try = [
        ("mp4v", ".mp4"),
        ("avc1", ".mp4"),
        ("XVID", ".avi"),
        ("MJPG", ".avi"),
    ]

    for fourcc_str, fallback_ext in codecs_to_try:
        try:
            target_path = output_path
            # If codec requires avi container, adjust extension
            if fallback_ext == ".avi" and target_path.suffix.lower() != ".avi":
                target_path = target_path.with_suffix(".avi")

            fourcc = cv2.VideoWriter_fourcc(*fourcc_str)
            writer = cv2.VideoWriter(str(target_path), fourcc, fps, (width, height))

            if writer.isOpened():
                print(f"[INFO] Initialized VideoWriter using codec '{fourcc_str}' -> {target_path}")
                return writer
            else:
                writer.release()
        except Exception as e:
            continue

    print(f"[WARNING] Could not initialize VideoWriter for '{output_path}'. Video recording will be disabled.")
    return None


def open_video_source(
    source_spec: Union[str, int]
) -> Tuple[cv2.VideoCapture, bool, str]:
    """
    Open video capture device or file with comprehensive validation.

    Args:
        source_spec: File path string or integer camera device ID.

    Returns:
        cap: cv2.VideoCapture object.
        is_webcam: Boolean flag.
        source_desc: Informative description string.
    """
    is_webcam = False
    source_desc = ""

    # Check if input is a camera device index (e.g. 0, 1, or string "0")
    if isinstance(source_spec, int) or (isinstance(source_spec, str) and source_spec.isdigit()):
        cam_id = int(source_spec)
        is_webcam = True
        source_desc = f"Webcam Device [Index: {cam_id}]"
        # On Windows, cv2.CAP_DSHOW provides fast, reliable DirectShow camera access
        cap = cv2.VideoCapture(cam_id, cv2.CAP_DSHOW)
        if not cap.isOpened():
            # Fallback to default backend
            cap = cv2.VideoCapture(cam_id)
    else:
        file_path = Path(source_spec)
        source_desc = f"Video File [{file_path.resolve()}]"

        if not file_path.exists():
            raise FileNotFoundError(
                f"Input video file does not exist: {file_path.resolve()}\n"
                f"Please verify the path or place a test video inside the 'data/' directory."
            )

        cap = cv2.VideoCapture(str(file_path))

    if not cap.isOpened():
        raise IOError(
            f"Failed to open video source: {source_desc}.\n"
            f"Please verify the file format (recommended: .mp4, .avi) or camera permissions."
        )

    return cap, is_webcam, source_desc


def process_video_pipeline(
    input_source: Union[str, int],
    csv_output_path: Path,
    video_output_path: Optional[Path] = None,
    dict_name: str = "DICT_4X4_50",
    display: bool = True,
    save_video: bool = True,
) -> Dict[str, Any]:
    """
    Execute full video loading, ArUco marker detection, CSV logging, and video export.

    Args:
        input_source: File path string or camera index.
        csv_output_path: Path where detection CSV will be saved.
        video_output_path: Path where annotated MP4 will be saved.
        dict_name: ArUco dictionary identifier.
        display: Whether to open a live cv2.imshow GUI preview window.
        save_video: Whether to save the annotated video file.

    Returns:
        Summary dictionary with execution statistics.
    """
    # 1. Initialize ArUco detector
    detector, dictionary, detector_params = init_aruco_detector(dict_name)

    # 2. Open input video or camera stream
    cap, is_webcam, source_desc = open_video_source(input_source)

    # 3. Retrieve video stream properties
    raw_width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    raw_height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    raw_fps = cap.get(cv2.CAP_PROP_FPS)
    total_frames_expected = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))

    # Guard against invalid FPS reported by some video containers or webcams
    fps = raw_fps if (raw_fps is not None and 1.0 <= raw_fps <= 120.0) else 30.0

    print("\n" + "=" * 65)
    print("  IE415 SLAM - MARKER DETECTION PIPELINE INITIALIZED")
    print("=" * 65)
    print(f"  Input Source       : {source_desc}")
    print(f"  Dictionary         : {dict_name}")
    print(f"  Input Resolution   : {raw_width} x {raw_height} px")
    print(f"  Operating FPS      : {fps:.2f} (Reported: {raw_fps})")
    if not is_webcam and total_frames_expected > 0:
        print(f"  Total Video Frames : {total_frames_expected}")
    print(f"  Live Window Display: {'Enabled (Press Q to quit)' if display else 'Disabled (Headless)'}")
    print(f"  CSV Output File    : {csv_output_path.resolve()}")
    if save_video and video_output_path:
        print(f"  Video Output File  : {video_output_path.resolve()}")
    print("=" * 65 + "\n")

    # 4. Initialize VideoWriter if requested
    writer = None
    if save_video and video_output_path is not None:
        writer = initialize_video_writer(
            output_path=video_output_path,
            fps=fps,
            width=raw_width,
            height=raw_height,
        )

    # Prepare results container
    csv_rows: List[Dict[str, Union[int, float]]] = []
    unique_ids_detected = set()
    total_frames_processed = 0
    total_observations = 0

    window_title = "IE415 SLAM - ArUco Marker Detection [Press Q to Exit]"
    start_wall_time = time.time()
    last_ui_refresh = time.time()

    # Pre-calculate delay between frames for realistic playback speed
    playback_delay_ms = max(1, int(1000.0 / fps))

    try:
        while True:
            ret, frame = cap.read()
            if not ret or frame is None:
                # End of video stream reached
                break

            # Calculate frame timestamp in seconds
            # Use deterministic frame index / fps for consistency and reproducibility
            timestamp_seconds = total_frames_processed / fps

            # Detect markers
            corners, ids = detect_markers_in_frame(
                frame=frame,
                detector=detector,
                dictionary=dictionary,
                detector_params=detector_params,
            )

            # Log observations
            if ids is not None and len(ids) > 0:
                frame_observations = extract_marker_observations(
                    frame_number=total_frames_processed,
                    timestamp_seconds=timestamp_seconds,
                    corners=corners,
                    ids=ids,
                )
                csv_rows.extend(frame_observations)
                total_observations += len(frame_observations)

                for single_id in ids:
                    val = int(single_id[0]) if hasattr(single_id, "__len__") else int(single_id)
                    unique_ids_detected.add(val)

            # Annotate frame
            annotated_frame = render_annotations(
                frame=frame,
                corners=corners,
                ids=ids,
                frame_number=total_frames_processed,
                timestamp_seconds=timestamp_seconds,
                fps=fps,
            )

            # Write annotated frame to output video file
            if writer is not None:
                writer.write(annotated_frame)

            # Display frame preview if GUI is enabled
            if display:
                cv2.imshow(window_title, annotated_frame)
                key = cv2.waitKey(playback_delay_ms) & 0xFF
                if key in (ord("q"), ord("Q"), 27):  # 'q' or ESC to stop
                    print("\n[INFO] User requested early termination (pressed 'Q').")
                    break

            total_frames_processed += 1

            # Periodic console progress report (every 60 frames)
            if total_frames_processed % 60 == 0:
                progress_pct = (
                    f" ({total_frames_processed / total_frames_expected * 100:.1f}%)"
                    if (not is_webcam and total_frames_expected > 0)
                    else ""
                )
                print(
                    f"[PROGRESS] Frame {total_frames_processed}{progress_pct} | "
                    f"Observations so far: {total_observations} | "
                    f"Unique IDs: {sorted(list(unique_ids_detected))}"
                )

    except KeyboardInterrupt:
        print("\n[INFO] Keyboard interrupt received. Finalizing output files...")

    finally:
        # Cleanup video stream and writers
        cap.release()
        if writer is not None:
            writer.release()
        if display:
            cv2.destroyAllWindows()

    elapsed_wall_time = time.time() - start_wall_time

    # 5. Save observations to CSV file
    csv_output_path.parent.mkdir(parents=True, exist_ok=True)
    with open(csv_output_path, mode="w", newline="", encoding="utf-8") as csv_file:
        writer_obj = csv.DictWriter(csv_file, fieldnames=CSV_COLUMNS)
        writer_obj.writeheader()
        if csv_rows:
            writer_obj.writerows(csv_rows)

    sorted_unique_ids = sorted(list(unique_ids_detected))

    # 6. Print Summary Statistics (Required Feature 7)
    print("\n" + "=" * 65)
    print("  IE415 SLAM - MILESTONE 1 PROCESSING SUMMARY")
    print("=" * 65)
    print(f"  Total frames processed        : {total_frames_processed}")
    print(f"  Total marker observations     : {total_observations}")
    print(f"  Number of unique marker IDs   : {len(sorted_unique_ids)}")
    print(f"  List of unique detected IDs   : {sorted_unique_ids}")
    print(f"  Elapsed wall-clock time       : {elapsed_wall_time:.2f} seconds")
    if elapsed_wall_time > 0 and total_frames_processed > 0:
        print(f"  Average processing speed      : {total_frames_processed / elapsed_wall_time:.1f} FPS")
    print(f"  Output CSV location           : {csv_output_path.resolve()}")
    if save_video and video_output_path:
        print(f"  Output annotated video location: {video_output_path.resolve()}")
    else:
        print(f"  Output annotated video        : Skipped / Disabled")
    print("=" * 65 + "\n")

    return {
        "total_frames": total_frames_processed,
        "total_observations": total_observations,
        "unique_marker_ids": sorted_unique_ids,
        "csv_path": str(csv_output_path.resolve()),
        "video_path": str(video_output_path.resolve()) if (save_video and video_output_path) else None,
        "elapsed_time": elapsed_wall_time,
    }


def build_arg_parser() -> argparse.ArgumentParser:
    """Build CLI argument parser."""
    parser = argparse.ArgumentParser(
        description="IE415 SLAM - Milestone 1: ArUco Marker Video Detection Pipeline",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument(
        "--input",
        "-i",
        type=str,
        help="Path to the input video file (e.g. data/sample.mp4) or camera ID number.",
    )
    group.add_argument(
        "--webcam",
        "-w",
        type=int,
        nargs="?",
        const=0,
        help="Launch detection using a connected webcam device (default index: 0).",
    )

    parser.add_argument(
        "--csv_output",
        type=str,
        default="results/marker_detections.csv",
        help="Path to write the output observations CSV file.",
    )
    parser.add_argument(
        "--video_output",
        type=str,
        default="results/detected_video.mp4",
        help="Path to write the annotated video file.",
    )
    parser.add_argument(
        "--dict",
        type=str,
        default="DICT_4X4_50",
        choices=list(ARUCO_DICTIONARY_MAP.keys()),
        help="OpenCV ArUco dictionary identifier.",
    )
    parser.add_argument(
        "--no-display",
        action="store_true",
        help="Disable live GUI display window (headless processing mode).",
    )
    parser.add_argument(
        "--no-save-video",
        action="store_true",
        help="Do not save the annotated output video file (faster processing).",
    )
    return parser


def main() -> None:
    """Main CLI entry point."""
    parser = build_arg_parser()
    args = parser.parse_args()

    # Anchor paths relative to project root or current working directory
    script_dir = Path(__file__).resolve().parent

    csv_out = Path(args.csv_output)
    if not csv_out.is_absolute():
        csv_out = script_dir / csv_out

    vid_out = Path(args.video_output)
    if not vid_out.is_absolute():
        vid_out = script_dir / vid_out

    # Determine input source
    if args.webcam is not None:
        input_source: Union[str, int] = args.webcam
    else:
        # Check if input is a digit (camera index passed to --input)
        if args.input.isdigit():
            input_source = int(args.input)
        else:
            in_path = Path(args.input)
            input_source = str((script_dir / in_path).resolve()) if not in_path.is_absolute() else str(in_path)

    try:
        process_video_pipeline(
            input_source=input_source,
            csv_output_path=csv_out,
            video_output_path=vid_out,
            dict_name=args.dict,
            display=not args.no_display,
            save_video=not args.no_save_video,
        )
    except FileNotFoundError as fnf_err:
        print(f"\n[ERROR] File Error: {fnf_err}")
        sys.exit(1)
    except IOError as io_err:
        print(f"\n[ERROR] I/O Error: {io_err}")
        sys.exit(1)
    except Exception as exc:
        print(f"\n[ERROR] Unexpected error in pipeline: {exc}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()

