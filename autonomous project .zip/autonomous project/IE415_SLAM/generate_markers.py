"""
==============================================================================
IE415: Visual-Inertial SLAM with Fiducial Landmark Anchors
Milestone 1: Laptop-Based Video Loading and ArUco Marker Detection Pipeline
Module: generate_markers.py
==============================================================================

Description:
    Generates fiducial ArUco marker images using OpenCV's ArUco module.
    Saves the generated markers as high-contrast PNG images into a specified
    directory for printing and physical landmark anchoring.

Dictionary:
    OpenCV DICT_4X4_50 (4x4 bits, 50 unique markers, IDs 0-49).

Usage:
    # Generate default 10 markers (IDs 0 to 9, size 400x400)
    python generate_markers.py

    # Generate custom number of markers with custom size
    python generate_markers.py --count 15 --size 500 --output_dir markers

    # Generate markers with printed ID label banners for easy physical handling
    python generate_markers.py --count 10 --add_label
==============================================================================
"""

import argparse
import sys
from pathlib import Path
from typing import List, Optional

try:
    import cv2
    import numpy as np
except ImportError as err:
    print(f"\n[ERROR] Required package missing: {err}")
    print("Please install requirements using:")
    print("    pip install -r requirements.txt\n")
    sys.exit(1)


# Map of commonly used ArUco dictionaries for future extensibility
ARUCO_DICTIONARY_MAP = {
    "DICT_4X4_50": cv2.aruco.DICT_4X4_50,
    "DICT_4X4_100": cv2.aruco.DICT_4X4_100,
    "DICT_4X4_250": cv2.aruco.DICT_4X4_250,
    "DICT_4X4_1000": cv2.aruco.DICT_4X4_1000,
    "DICT_5X5_50": cv2.aruco.DICT_5X5_50,
    "DICT_5X5_100": cv2.aruco.DICT_5X5_100,
    "DICT_6X6_50": cv2.aruco.DICT_6X6_50,
    "DICT_6X6_250": cv2.aruco.DICT_6X6_250,
}


def get_aruco_dictionary(dict_name: str = "DICT_4X4_50"):
    """
    Retrieve the requested OpenCV ArUco dictionary object.

    Args:
        dict_name: Name of predefined ArUco dictionary (default: 'DICT_4X4_50').

    Returns:
        cv2.aruco.Dictionary instance.
    """
    if dict_name not in ARUCO_DICTIONARY_MAP:
        valid_keys = ", ".join(ARUCO_DICTIONARY_MAP.keys())
        raise ValueError(f"Invalid dictionary '{dict_name}'. Choose from: {valid_keys}")

    dict_id = ARUCO_DICTIONARY_MAP[dict_name]

    # Modern OpenCV (4.7+) uses getPredefinedDictionary
    if hasattr(cv2.aruco, "getPredefinedDictionary"):
        return cv2.aruco.getPredefinedDictionary(dict_id)
    # Legacy OpenCV 4.x fallback
    elif hasattr(cv2.aruco, "Dictionary_get"):
        return cv2.aruco.Dictionary_get(dict_id)
    else:
        raise RuntimeError("OpenCV ArUco module dictionary getter could not be located.")


def generate_single_marker(
    dictionary,
    marker_id: int,
    side_pixels: int = 400,
    border_bits: int = 1,
    margin_pixels: int = 20,
    add_label: bool = False,
    dict_name: str = "DICT_4X4_50",
) -> np.ndarray:
    """
    Generate an individual ArUco marker image as a numpy array.

    Includes a white quiet zone (margin) to ensure proper contour detection
    when placed or stuck on dark physical surfaces.

    Args:
        dictionary: OpenCV ArUco dictionary.
        marker_id: Unique integer ID of the marker.
        side_pixels: Width and height of the inner marker in pixels.
        border_bits: Number of bits for the marker's outer black border.
        margin_pixels: White margin (quiet zone) around the marker.
        add_label: If True, adds a small text banner below indicating the ID.
        dict_name: Name of dictionary for display purposes.

    Returns:
        np.ndarray containing 8-bit grayscale or BGR marker image.
    """
    # Generate raw marker bitmap using modern OpenCV API with legacy fallback
    if hasattr(cv2.aruco, "generateImageMarker"):
        marker_img = cv2.aruco.generateImageMarker(
            dictionary, marker_id, side_pixels, borderBits=border_bits
        )
    elif hasattr(cv2.aruco, "drawMarker"):
        marker_img = cv2.aruco.drawMarker(
            dictionary, marker_id, side_pixels, borderBits=border_bits
        )
    else:
        # Some custom wrappers allow dictionary.generateImageMarker
        marker_img = dictionary.generateImageMarker(
            marker_id, side_pixels, borderBits=border_bits
        )

    # Ensure 8-bit single channel image
    if len(marker_img.shape) == 3:
        marker_img = cv2.cvtColor(marker_img, cv2.COLOR_BGR2GRAY)

    # Add quiet zone (white margin) around marker
    # This is critical for fiducial marker detectors to identify the outer boundary
    if margin_pixels > 0:
        marker_img = cv2.copyMakeBorder(
            marker_img,
            top=margin_pixels,
            bottom=margin_pixels,
            left=margin_pixels,
            right=margin_pixels,
            borderType=cv2.BORDER_CONSTANT,
            value=255,  # Pure white
        )

    # Optionally add human-readable text label banner at bottom
    if add_label:
        h, w = marker_img.shape
        label_height = 40
        canvas = np.full((h + label_height, w), 255, dtype=np.uint8)
        canvas[0:h, 0:w] = marker_img

        label_text = f"ArUco {dict_name} | ID: {marker_id}"
        font = cv2.FONT_HERSHEY_SIMPLEX
        font_scale = 0.55
        thickness = 1
        text_size = cv2.getTextSize(label_text, font, font_scale, thickness)[0]
        text_x = max(10, (w - text_size[0]) // 2)
        text_y = h + int(label_height * 0.7)

        cv2.putText(
            canvas,
            label_text,
            (text_x, text_y),
            font,
            font_scale,
            (0,),
            thickness,
            cv2.LINE_AA,
        )
        return canvas

    return marker_img


def generate_marker_set(
    start_id: int = 0,
    count: int = 10,
    side_pixels: int = 400,
    border_bits: int = 1,
    margin_pixels: int = 20,
    output_dir: Path = Path("markers"),
    dict_name: str = "DICT_4X4_50",
    add_label: bool = False,
) -> List[Path]:
    """
    Generate and save a contiguous set of ArUco marker images.

    Args:
        start_id: First marker ID to generate.
        count: Total number of unique markers to generate.
        side_pixels: Width/height of the marker in pixels.
        border_bits: Number of bits for the black boundary.
        margin_pixels: White margin (quiet zone) in pixels.
        output_dir: Destination folder path for PNG images.
        dict_name: ArUco dictionary name.
        add_label: Whether to append readable ID text banner.

    Returns:
        List of Path objects for all successfully generated files.
    """
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    dictionary = get_aruco_dictionary(dict_name)
    generated_paths: List[Path] = []

    print(f"\n[INFO] Generating {count} ArUco markers using dictionary: '{dict_name}'")
    print(f"[INFO] Output directory: {output_dir.resolve()}")
    print(f"[INFO] Marker size: {side_pixels}x{side_pixels} px (borderBits={border_bits}, margin={margin_pixels} px)\n")

    for offset in range(count):
        marker_id = start_id + offset

        # Range check for the selected dictionary (e.g. DICT_4X4_50 allows IDs 0-49)
        max_id = 49 if "50" in dict_name else 999
        if marker_id > max_id:
            print(f"[WARNING] Skipping marker ID {marker_id}: Exceeds dictionary max ID {max_id}.")
            continue

        marker_img = generate_single_marker(
            dictionary=dictionary,
            marker_id=marker_id,
            side_pixels=side_pixels,
            border_bits=border_bits,
            margin_pixels=margin_pixels,
            add_label=add_label,
            dict_name=dict_name,
        )

        file_name = f"marker_{marker_id}.png"
        file_path = output_dir / file_name

        success = cv2.imwrite(str(file_path), marker_img)
        if success:
            generated_paths.append(file_path)
            print(f"  [+] Saved Marker ID {marker_id:02d} -> {file_path}")
        else:
            print(f"  [-] FAILED to write marker ID {marker_id:02d} to {file_path}")

    return generated_paths


def build_arg_parser() -> argparse.ArgumentParser:
    """Build command line argument parser."""
    parser = argparse.ArgumentParser(
        description="IE415 SLAM - Milestone 1: ArUco Marker Generator",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    parser.add_argument(
        "--count",
        type=int,
        default=10,
        help="Number of unique markers to generate (e.g. 10 for IDs 0-9).",
    )
    parser.add_argument(
        "--start_id",
        type=int,
        default=0,
        help="Starting marker ID (0-indexed).",
    )
    parser.add_argument(
        "--size",
        type=int,
        default=400,
        help="Marker resolution (width and height in pixels).",
    )
    parser.add_argument(
        "--border_bits",
        type=int,
        default=1,
        help="Width of the ArUco marker black outer border in bits.",
    )
    parser.add_argument(
        "--margin",
        type=int,
        default=20,
        help="White quiet-zone border padding in pixels (improves detection).",
    )
    parser.add_argument(
        "--output_dir",
        type=str,
        default="markers",
        help="Relative or absolute path to the directory where markers will be saved.",
    )
    parser.add_argument(
        "--dict",
        type=str,
        default="DICT_4X4_50",
        choices=list(ARUCO_DICTIONARY_MAP.keys()),
        help="OpenCV ArUco dictionary identifier.",
    )
    parser.add_argument(
        "--add_label",
        action="store_true",
        help="Include a human-readable text label banner under the marker for printing.",
    )
    return parser


def main() -> None:
    """Main CLI entry point."""
    parser = build_arg_parser()
    args = parser.parse_args()

    # Anchor relative output paths to current working directory or script directory
    script_dir = Path(__file__).resolve().parent
    output_dir = Path(args.output_dir)
    if not output_dir.is_absolute():
        output_dir = script_dir / output_dir

    try:
        paths = generate_marker_set(
            start_id=args.start_id,
            count=args.count,
            side_pixels=args.size,
            border_bits=args.border_bits,
            margin_pixels=args.margin,
            output_dir=output_dir,
            dict_name=args.dict,
            add_label=args.add_label,
        )

        print("\n" + "=" * 65)
        print("  ARUCO MARKER GENERATION COMPLETED SUCCESSFULLY")
        print("=" * 65)
        print(f"  Total Markers Created : {len(paths)}")
        print(f"  ID Range              : [{args.start_id} .. {args.start_id + len(paths) - 1}]")
        print(f"  Output Directory      : {output_dir.resolve()}")
        print(f"  Dictionary            : {args.dict}")
        print("=" * 65)
        print("\n[NOTE FOR FUTURE MILESTONES (Camera Calibration & 3D Pose)]:")
        print("  When printing these markers on paper for real-world SLAM anchoring:")
        print("  1. Print without scaling (100% scale).")
        print("  2. Measure the physical black square side length with a ruler (e.g. 0.05m or 0.10m).")
        print("  3. Keep the measured side length noted for Milestone 2's cv2.solvePnP() pose estimation.\n")

    except Exception as e:
        print(f"\n[ERROR] Marker generation failed: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()

