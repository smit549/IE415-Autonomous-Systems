# Markers Directory (`markers/`)

This directory stores generated ArUco fiducial marker PNG images.

### Generating Markers:
Run:
```powershell
python generate_markers.py
```
This generates 10 high-contrast marker images (`marker_0.png` through `marker_9.png`) using dictionary `DICT_4X4_50`.

### Printing Guidelines:
- Print markers at 100% scale (disable "fit to page").
- Measure the inner black square side length with a ruler (e.g., 0.05 m or 0.10 m).
- Note this exact dimension for 3D pose estimation in Milestone 2.

