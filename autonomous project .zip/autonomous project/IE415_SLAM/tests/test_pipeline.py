"""
==============================================================================
IE415: Visual-Inertial SLAM with Fiducial Landmark Anchors
Milestone 1: Automated Unit & Pipeline Verification Tests
Module: tests/test_pipeline.py
==============================================================================

Description:
    Provides automated unit tests and validation checks for Milestone 1:
      1. ArUco marker generation (IDs 0-9, dimensions, valid dictionary).
      2. ArUco detection on single and multiple markers.
      3. Negative testing on blank frames (no false positive / fake detections).
      4. Corner coordinate extraction (4 corners per detected marker).
      5. CSV logging schema validation (exact 11 required columns).
      6. Graceful handling of invalid video paths.
      7. End-to-end synthetic video execution pipeline.

Execution:
    python -m unittest tests/test_pipeline.py -v
    or
    pytest tests/
==============================================================================
"""

import csv
import sys
import tempfile
import unittest
from pathlib import Path

# Add project root to sys.path so tests can import modules directly
PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

try:
    import cv2
    import numpy as np
    from detect_markers import (
        CSV_COLUMNS,
        detect_markers_in_frame,
        extract_marker_observations,
        init_aruco_detector,
        open_video_source,
        process_video_pipeline,
    )
    from generate_markers import (
        generate_marker_set,
        generate_single_marker,
        get_aruco_dictionary,
    )
    from create_sample_video import create_synthetic_marker_video
except ImportError as err:
    print(f"[TEST SETUP ERROR] Missing dependency: {err}")
    print("Run: pip install -r requirements.txt")


class TestArUcoGeneration(unittest.TestCase):
    """Test suite for ArUco marker generation functions."""

    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory()
        self.output_dir = Path(self.temp_dir.name)

    def tearDown(self):
        self.temp_dir.cleanup()

    def test_single_marker_generation(self):
        """Verify generation of a single ArUco marker image."""
        dictionary = get_aruco_dictionary("DICT_4X4_50")
        img = generate_single_marker(
            dictionary=dictionary,
            marker_id=0,
            side_pixels=200,
            border_bits=1,
            margin_pixels=10,
        )
        self.assertIsNotNone(img, "Marker image should not be None")
        self.assertEqual(len(img.shape), 2, "Marker image should be 2D grayscale")
        # 200px inner + 2*10px margin = 220px
        self.assertEqual(img.shape[0], 220)
        self.assertEqual(img.shape[1], 220)

    def test_marker_set_generation_10_markers(self):
        """Verify generation of 10 unique markers with IDs 0 to 9."""
        paths = generate_marker_set(
            start_id=0,
            count=10,
            side_pixels=200,
            output_dir=self.output_dir,
            dict_name="DICT_4X4_50",
        )
        self.assertEqual(len(paths), 10, "Should generate exactly 10 marker files")
        for i, p in enumerate(paths):
            self.assertTrue(p.exists(), f"File {p} must exist")
            self.assertEqual(p.name, f"marker_{i}.png")
            # Verify file is readable as an image
            read_img = cv2.imread(str(p), cv2.IMREAD_GRAYSCALE)
            self.assertIsNotNone(read_img, f"File {p} must be a valid readable image")


class TestArUcoDetection(unittest.TestCase):
    """Test suite for ArUco marker detection and coordinate extraction."""

    @classmethod
    def setUpClass(cls):
        cls.detector, cls.dictionary, cls.params = init_aruco_detector("DICT_4X4_50")

    def test_detect_single_marker(self):
        """Verify that a synthesized marker image can be detected with correct ID and 4 corners."""
        marker_img = generate_single_marker(
            self.dictionary,
            marker_id=5,
            side_pixels=200,
            margin_pixels=40,
        )
        corners, ids = detect_markers_in_frame(
            marker_img, self.detector, self.dictionary, self.params
        )
        self.assertIsNotNone(ids, "Detector should detect marker ID 5")
        self.assertEqual(len(ids), 1, "Exactly one marker should be detected")
        self.assertEqual(int(ids[0][0]), 5, "Detected marker ID must match 5")
        self.assertEqual(len(corners), 1, "Corners list must have 1 entry")
        # Check shape of corners
        pts = corners[0][0] if corners[0].ndim == 3 else corners[0]
        self.assertEqual(pts.shape, (4, 2), "Corner array must have shape (4, 2)")

    def test_detect_multiple_markers_in_same_frame(self):
        """Verify detection of multiple different markers within a single frame."""
        canvas = np.full((400, 600), 255, dtype=np.uint8)

        m1 = generate_single_marker(self.dictionary, marker_id=2, side_pixels=120, margin_pixels=10)
        m2 = generate_single_marker(self.dictionary, marker_id=7, side_pixels=120, margin_pixels=10)

        # Place m1 at (50, 50) and m2 at (50, 350)
        canvas[50 : 50 + m1.shape[0], 50 : 50 + m1.shape[1]] = m1
        canvas[50 : 50 + m2.shape[0], 350 : 350 + m2.shape[1]] = m2

        corners, ids = detect_markers_in_frame(
            canvas, self.detector, self.dictionary, self.params
        )
        self.assertIsNotNone(ids, "Multiple markers should be detected")
        self.assertEqual(len(ids), 2, "Expected 2 detected markers")
        detected_set = {int(i[0]) for i in ids}
        self.assertEqual(detected_set, {2, 7}, "Detected IDs should be exactly {2, 7}")

    def test_no_marker_in_blank_frame(self):
        """Verify that a blank image produces NO detections and NO fake observations."""
        blank_frame = np.full((300, 300, 3), 240, dtype=np.uint8)
        corners, ids = detect_markers_in_frame(
            blank_frame, self.detector, self.dictionary, self.params
        )
        observations = extract_marker_observations(
            frame_number=0,
            timestamp_seconds=0.0,
            corners=corners,
            ids=ids,
        )
        self.assertEqual(len(observations), 0, "No observations should be generated for blank frame")


class TestCSVLoggingSchema(unittest.TestCase):
    """Test suite for CSV observation schema and field validation."""

    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory()
        self.csv_path = Path(self.temp_dir.name) / "test_detections.csv"

    def tearDown(self):
        self.temp_dir.cleanup()

    def test_csv_schema_columns(self):
        """Verify that the CSV output matches the exact 11 required columns."""
        expected_columns = [
            "frame_number",
            "timestamp_seconds",
            "marker_id",
            "corner_1_x",
            "corner_1_y",
            "corner_2_x",
            "corner_2_y",
            "corner_3_x",
            "corner_3_y",
            "corner_4_x",
            "corner_4_y",
        ]
        self.assertEqual(CSV_COLUMNS, expected_columns, "CSV columns must match specification")

        # Mock corners array for 1 marker: shape (1, 4, 2)
        mock_corners = [
            np.array([[[10.5, 20.2], [50.1, 20.4], [50.0, 60.3], [10.2, 60.1]]], dtype=np.float32)
        ]
        mock_ids = np.array([[3]], dtype=np.int32)

        rows = extract_marker_observations(
            frame_number=14,
            timestamp_seconds=0.4667,
            corners=mock_corners,
            ids=mock_ids,
        )

        self.assertEqual(len(rows), 1)
        row = rows[0]
        self.assertEqual(row["frame_number"], 14)
        self.assertEqual(row["marker_id"], 3)
        self.assertAlmostEqual(row["timestamp_seconds"], 0.4667, places=4)
        self.assertAlmostEqual(row["corner_1_x"], 10.5, places=1)
        self.assertAlmostEqual(row["corner_1_y"], 20.2, places=1)
        self.assertAlmostEqual(row["corner_2_x"], 50.1, places=1)
        self.assertAlmostEqual(row["corner_2_y"], 20.4, places=1)
        self.assertAlmostEqual(row["corner_3_x"], 50.0, places=1)
        self.assertAlmostEqual(row["corner_3_y"], 60.3, places=1)
        self.assertAlmostEqual(row["corner_4_x"], 10.2, places=1)
        self.assertAlmostEqual(row["corner_4_y"], 60.1, places=1)

        # Write to CSV and read back
        with open(self.csv_path, mode="w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=CSV_COLUMNS)
            writer.writeheader()
            writer.writerows(rows)

        with open(self.csv_path, mode="r", encoding="utf-8") as f:
            reader = csv.reader(f)
            header = next(reader)
            data_row = next(reader)

        self.assertEqual(header, expected_columns)
        self.assertEqual(data_row[0], "14")
        self.assertEqual(data_row[2], "3")


class TestErrorHandling(unittest.TestCase):
    """Test suite for error handling on invalid paths and inputs."""

    def test_invalid_video_path(self):
        """Verify that an invalid video path raises a FileNotFoundError gracefully."""
        invalid_path = "non_existent_folder/fake_video_12345.mp4"
        with self.assertRaises(FileNotFoundError):
            open_video_source(invalid_path)


class TestEndToEndPipeline(unittest.TestCase):
    """Test suite for full pipeline execution on a synthesized video."""

    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory()
        self.work_dir = Path(self.temp_dir.name)

    def tearDown(self):
        self.temp_dir.cleanup()

    def test_synthetic_video_pipeline(self):
        """Synthesize a 1.0s video, execute pipeline, and verify CSV and MP4 output."""
        synth_video = self.work_dir / "test_synth.mp4"
        csv_out = self.work_dir / "detections.csv"
        video_out = self.work_dir / "annotated.mp4"

        # Create short 1-second synthetic video with markers 0 and 1
        create_synthetic_marker_video(
            output_path=synth_video,
            duration_seconds=1.0,
            fps=30.0,
            marker_ids=[0, 1],
        )
        self.assertTrue(synth_video.exists(), "Synthetic video must be generated")

        # Run pipeline headless
        summary = process_video_pipeline(
            input_source=str(synth_video),
            csv_output_path=csv_out,
            video_output_path=video_out,
            display=False,
            save_video=True,
        )

        self.assertGreater(summary["total_frames"], 0, "Frames should have been processed")
        self.assertGreater(summary["total_observations"], 0, "Observations should be recorded")
        self.assertTrue(0 in summary["unique_marker_ids"], "Marker 0 should be detected")
        self.assertTrue(csv_out.exists(), "Output CSV must exist")
        self.assertGreater(csv_out.stat().st_size, 0, "Output CSV must not be empty")


if __name__ == "__main__":
    unittest.main()

