# Milestone 1 Technical Report
## Laptop-Based Video Loading and ArUco Marker Detection Pipeline

**Course Project:** IE415 Autonomous Systems / Robotics  
**System Title:** Visual-Inertial SLAM with Fiducial Landmark Anchors  
**Milestone:** 1 (Preliminary Milestone)  
**Author:** Priyam Vaishnav  
**Environment:** Windows 10/11 x64, Python 3.10+, OpenCV Contrib 4.8+  

---

## 1. Executive Summary & Milestone Objective

In monocular and visual-inertial SLAM systems, accumulated dead-reckoning drift poses a primary challenge over extended trajectories. While Visual-Inertial Odometry (VIO) fuses visual feature tracking with inertial measurements to suppress high-frequency errors, low-frequency position and yaw drift inevitably compound without global geometric anchors.

The broader objective of this project is to implement a **Phone-Laptop Hybrid Visual-Inertial SLAM system** that integrates high-rate smartphone IMU data with camera video and fixed **ArUco fiducial landmarks** deployed throughout the environment to serve as metric spatial anchors.

**Milestone 1 focuses exclusively on the initial offline vision frontend:**
1. Establishing an environment for reproducible computer vision processing on a Windows workstation.
2. Generating a standardized set of fiducial ArUco markers (`DICT_4X4_50`, IDs 0–9).
3. Developing a robust video ingestion and decoding engine supporting both recorded video files and live webcam streams.
4. Detecting ArUco markers in each frame using modern OpenCV 4.7+ APIs, extracting 2D subpixel corner coordinates, and associating persistent IDs.
5. Logging all observations to a standardized CSV schema (`results/marker_detections.csv`).
6. Exporting full-resolution annotated video streams (`results/detected_video.mp4`) with diagnostic visual overlays.
7. Providing a structured unit-testing and validation suite for academic verification.

---

## 2. System Architecture & Context

The planned full SLAM system utilizes a decoupled hybrid architecture:

```
+-------------------------------------------------------------------------+
|                       ANDROID SMARTPHONE (Capture)                       |
|  - Camera Stream (30 FPS, fixed exposure/focus)                         |
|  - Microsecond Timestamps                                               |
|  - 6-DoF IMU: 3-Axis Gyroscope (200 Hz) + 3-Axis Accelerometer (200 Hz)  |
+------------------------------------+------------------------------------+
                                     | Data Transfer (USB / Session Dumps)
                                     v
+-------------------------------------------------------------------------+
|                       LAPTOP WORKSTATION (SLAM Engine)                  |
|                                                                         |
|  =====================================================================  |
|  [MILESTONE 1 - IMPLEMENTED]                                            |
|  * Video Ingestion & Frame-by-Frame Decoding                            |
|  * ArUco Detector Pipeline (DICT_4X4_50)                                 |
|  * 2D Corner Extraction & ID Association                                |
|  * Structured CSV Observation Logging                                   |
|  * Diagnostic Video Visualization & Telemetry Overlay                   |
|  =====================================================================  |
|                                                                         |
|  [MILESTONE 2 - PLANNED NEXT]                                           |
|  * Intrinsic Calibration Matrix K and Distortion Coefficients D          |
|  * Marker Metric Dimensions (s = 0.10 m)                                |
|  * 3D Marker Pose Estimation via solvePnP [R | t]                        |
|                                                                         |
|  [MILESTONES 3 & 4 - PLANNED FUTURE]                                    |
|  * Hardware Camera-IMU Temporal Synchronization                         |
|  * OpenVINS Visual-Inertial Odometry Pipeline                           |
|  * Factor Graph / EKF Optimization with Fixed Landmark Anchor Residuals |
|  * Trajectory Ground-Truth Evaluation (ATE / RPE Metrics)               |
+-------------------------------------------------------------------------+
```

---

## 3. Implementation Details

### 3.1 ArUco Marker Generation (`generate_markers.py`)
- **Dictionary Selection:** `DICT_4X4_50` is chosen. It contains 50 unique binary matrices of size 4x4 bits. Compared to larger dictionaries (e.g., 6x6 or 7x7), 4x4 markers feature larger individual bit squares, enabling reliable detection at longer distances and lower camera resolutions under indoor motion blur.
- **Marker Generation API:** Uses modern OpenCV 4.7+ API `cv2.aruco.generateImageMarker()` with fallback to `cv2.aruco.drawMarker()` to guarantee version portability.
- **Quiet Zone (Margin):** Enforces a configurable 20px white padding around each marker (`cv2.copyMakeBorder`). This quiet zone is essential for the adaptive thresholding and contour extraction stages to cleanly isolate the outer black border against dark background materials.
- **Printable ID Banner:** Optionally embeds human-readable label headers below each marker to assist physical handling during experimental setup.

### 3.2 Video Loading & Decoding (`detect_markers.py`)
- **Source Agnosticism:** Seamlessly handles file-based inputs (`.mp4`, `.avi`, `.mov`) and live hardware video capture (`cv2.VideoCapture`).
- **DirectShow Windows Backend:** Uses `cv2.CAP_DSHOW` when opening webcams on Windows, avoiding slow initialization latencies common to default V4L/DirectShow wrappers.
- **Frame Rate & Resolution Preservation:** Captures video resolution (`CAP_PROP_FRAME_WIDTH`, `CAP_PROP_FRAME_HEIGHT`) and stream FPS (`CAP_PROP_FPS`). Employs safe fallbacks (defaulting to 30.0 FPS) if the underlying container reports invalid zero frame rates.
- **Playback & Headless Modes:** Supports real-time preview display with `cv2.imshow` and user interrupt handling (`Q` key), as well as a `--no-display` headless mode suitable for automated testing or compute clusters.

### 3.3 ArUco Marker Detection & Extraction Engine
- **Detector Architecture:** Implements the updated `cv2.aruco.ArucoDetector` interface initialized with `cv2.aruco.DetectorParameters`.
- **Detection Algorithm Stages:**
  1. *Adaptive Thresholding:* Converts input image to binary format to segment dark marker borders under varying indoor lighting conditions.
  2. *Contour Extraction & Polygon Approximation:* Detects closed contours and retains candidate 4-sided convex polygons.
  3. *Perspective Rectification (Homography):* Warps each candidate quad into a canonical square canonical grid.
  4. *Binary Code Extraction & Hamming Distance Matching:* Samples internal cells to extract the 4x4 bit code. Compares code against dictionary codewords, evaluating Hamming distance for error detection and single-bit error correction.
  5. *Subpixel Corner Refinement:* Employs corner subpixel interpolation to pinpoint exact continuous coordinates in pixel space.

### 3.4 Corner Identification & Ordering
Detected corners are extracted in a standardized clockwise sequence defined by OpenCV ArUco:
- **Corner 1:** Top-Left $(x_1, y_1)$ — visually marked with a distinct red circular dot in our diagnostic overlay to indicate marker orientation.
- **Corner 2:** Top-Right $(x_2, y_2)$
- **Corner 3:** Bottom-Right $(x_3, y_3)$
- **Corner 4:** Bottom-Left $(x_4, y_4)$

```
   (x1, y1) [Top-Left / Origin]  ●-------------------○  (x2, y2) [Top-Right]
                                 |                   |
                                 |    Marker ID      |
                                 |   DICT_4X4_50     |
                                 |                   |
   (x4, y4) [Bottom-Left]        ○-------------------○  (x3, y3) [Bottom-Right]
```

### 3.5 Structured Data Logging (`results/marker_detections.csv`)
For every frame where one or more markers are identified, observations are written to CSV with the exact 11 required columns:
```
frame_number, timestamp_seconds, marker_id, corner_1_x, corner_1_y, corner_2_x, corner_2_y, corner_3_x, corner_3_y, corner_4_x, corner_4_y
```
- **Constraint Compliance:** Frames with zero detections emit **no** rows, preventing phantom observations.
- **Multi-Marker Handling:** When $M$ markers appear in a single frame, $M$ separate rows are generated, sharing identical `frame_number` and `timestamp_seconds`.
- **Monotonic Timestamps:** Timestamp is derived deterministically as $t_k = k / \text{FPS}$, ensuring strict monotonicity across all hardware platforms.

### 3.6 Annotated Video Pipeline (`results/detected_video.mp4`)
- Encodes output video via `cv2.VideoWriter`.
- Prioritizes `mp4v` codec for native Windows compatibility, cascading to `avc1` or `XVID` if required.
- Visual elements rendered onto the frame:
  1. Green polygon perimeter outlining detected marker bounds.
  2. Floating marker ID text label.
  3. Red circular indicator at Corner 1 (top-left) highlighting coordinate system orientation.
  4. Top semi-transparent Heads-Up Display (HUD) displaying frame index, elapsed time, current FPS, and detected ID list.

---

## 4. Algorithms and Libraries Used

| Library / Module | Version | Academic Purpose |
|---|---|---|
| `opencv-contrib-python` | `>= 4.8.0.76` | Image ingestion, color space conversion, adaptive thresholding, ArUco fiducial pattern matching, VideoWriter encoding. |
| `cv2.aruco` | Contrib Module | Dictionary definitions (`DICT_4X4_50`), `ArucoDetector`, marker generation, corner refinement. |
| `numpy` | `>= 1.24.0` | Matrix representations, array manipulation, geometric coordinate transformations. |
| `pandas` | `>= 2.0.0` | Dataframe modeling, structured CSV verification, statistical inspection. |
| `unittest` / `pytest` | Standard / `>= 7.4.0` | Test harness for unit tests, boundary testing, and end-to-end synthetic video validation. |

---

## 5. Input and Output Specifications

### Inputs:
1. **Video File:** Path to recorded MP4, AVI, or MOV video (e.g. `data/sample_aruco_video.mp4`).
2. **Webcam Device:** Integer camera index (`0`, `1`, ...).
3. **Configuration Options:** CLI flags for dictionary selection, headless execution, and custom output destinations.

### Outputs:
1. **`markers/marker_*.png`:** 8-bit grayscale PNG files of generated ArUco markers.
2. **`results/marker_detections.csv`:** 11-column structured CSV log of all 2D landmark observations.
3. **`results/detected_video.mp4`:** Annotated diagnostic MP4 video.
4. **Console Telemetry:** Summary statistics printed upon stream closure.

---

## 6. Testing Procedure & Acceptance Criteria

A 9-point verification matrix was defined and executed to validate Milestone 1:

| # | Test Description | Procedure | Acceptance Criterion | Status |
|---|---|---|---|---|
| 1 | **Marker Generation** | Execute `generate_markers.py --count 10`. | 10 PNG files (`marker_0.png` .. `marker_9.png`) created with 400x400 inner resolution and white quiet zones. | Verified |
| 2 | **Video Ingestion** | Pass valid MP4 video path to `detect_markers.py`. | Video opens without errors; resolution and frame rate correctly reported. | Verified |
| 3 | **Marker ID Identification** | Detect markers from `DICT_4X4_50`. | Identified IDs match ground-truth marker IDs without misclassification. | Verified |
| 4 | **Corner Coordinate Extraction** | Query extracted corner coordinates for detected markers. | Four distinct $(x, y)$ coordinate pairs returned per detected marker. | Verified |
| 5 | **Multi-Marker Detection** | Place multiple distinct markers in a single frame. | Detector identifies all visible markers simultaneously and logs individual rows per marker. | Verified |
| 6 | **CSV Logging Integrity** | Inspect generated `marker_detections.csv`. | 11 columns matching specification; correct datatypes; zero fake rows for blank frames. | Verified |
| 7 | **Annotated Video Export** | Process video with video writer enabled. | Valid playable MP4 file written to `results/` matching original resolution. | Verified |
| 8 | **Invalid Path Handling** | Pass non-existent video path to pipeline. | Script exits cleanly with descriptive `FileNotFoundError` without unhandled crashes. | Verified |
| 9 | **Blank Video / Negative Test** | Process video containing zero markers. | Zero detection rows written to CSV; summary reports 0 observations; video written cleanly. | Verified |

### Automated Unit Test Suite (`tests/test_pipeline.py`)
Unit tests cover:
- `TestArUcoGeneration`: Single marker generation, 10-marker batch generation, file readability.
- `TestArUcoDetection`: Detection accuracy on synthetic images, multi-marker frames, negative test on blank frames.
- `TestCSVLoggingSchema`: CSV column verification, coordinate precision, dictionary schema serialization.
- `TestErrorHandling`: Non-existent file paths and invalid formats.
- `TestEndToEndPipeline`: End-to-end execution on a synthesized video stream.

---

## 7. Current Limitations & Assumptions

As per the approved scope for Milestone 1, the following limitations apply:
1. **2D Pixel Space Only:** Corner coordinates are recorded in image pixels $(u, v)$. 3D metric camera-to-marker pose vectors $[R \mid t]$ are not estimated in this milestone.
2. **Uncalibrated Monocular Camera:** Processing assumes a pinhole camera model without explicit lens distortion correction (radial/tangential) or intrinsic matrix calibration ($f_x, f_y, c_x, c_y$).
3. **No Sensor Fusion:** Smartphone IMU data (accelerometer and gyroscope) are not yet integrated.
4. **Lighting & Motion Blur Sensitivity:** High angular velocity motion blur from aggressive hand-held phone movement may degrade corner detection if exposure time is unconstrained.

---

## 8. Future Milestones & Integration Roadmap

### Milestone 2: Monocular Camera Calibration & 3D Pose Estimation
- **Camera Calibration:** Calibrate smartphone camera intrinsics using a printed ChArUco / chessboard grid. Compute camera intrinsic matrix $K \in \mathbb{R}^{3 \times 3}$ and distortion vector $D \in \mathbb{R}^5$ using `cv2.calibrateCamera`.
- **Perspective-n-Point (PnP):** Define physical marker 3D object points in the landmark frame (e.g., $s = 0.10$ m). Use `cv2.solvePnP` / `cv2.solvePnPGeneric` with the calibrated matrix $K$ and distortion coefficients $D$ to compute the 3D rotation vector $r$ and translation vector $t \in \mathbb{R}^3$ for each landmark relative to the camera frame:
  $$\mathbf{x}_{\text{cam}} = \mathbf{R} \, \mathbf{x}_{\text{marker}} + \mathbf{t}$$

### Milestone 3: Android Sensor Acquisition App
- Develop an Android client to capture synchronized H.264 camera video and high-rate (200 Hz) Android SensorManager IMU readings (`TYPE_ACCELEROMETER`, `TYPE_GYROSCOPE`).
- Log nanosecond sensor hardware timestamps alongside frame exposure timestamps for cross-sensor synchronization.

### Milestone 4: OpenVINS Integration & Landmark Anchor Graph SLAM
- Formulate the visual-inertial SLAM problem using OpenVINS (or GTSAM factor graph optimization).
- Fuse IMU preintegration factors with sparse visual feature tracks and fixed ArUco landmark 3D anchor observations.
- Evaluate absolute trajectory error (ATE) and relative pose error (RPE) against ground-truth trajectories to demonstrate loop closure and drift elimination.

