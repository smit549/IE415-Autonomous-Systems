"""
==============================================================================
IE415: Visual-Inertial SLAM with Fiducial Landmark Anchors
Milestone 1: Helper Utility - Synthetic Sample Video Generator
Module: create_sample_video.py
==============================================================================

Description:
    Generates a synthetic MP4 video file containing simulated camera motion
    observing ArUco markers (from DICT_4X4_50).
    
    This provides an immediate, offline test video for the detection pipeline
    before recording physical smartphone videos with real printed markers.

Usage:
    python create_sample_video.py
    python create_sample_video.py --output data/custom_sample.mp4 --duration 4
==============================================================================
"""

import argparse
import sys
from pathlib import Path

try:
    import cv2
    import numpy as np
except ImportError as err:
    print(f"[ERROR] Required package missing: {err}")
    print("Please install requirements using: pip install -r requirements.txt")
    sys.exit(1)

from generate_markers import generate_single_marker, get_aruco_dictionary


def create_synthetic_marker_video(
    output_path: Path,
    duration_seconds: float = 3.0,
    fps: float = 30.0,
    width: int = 640,
    height: int = 480,
    marker_ids: list = [0, 1, 2],
    marker_size: int = 100,
) -> Path:
    """
    Synthesize an MP4 video with animated ArUco markers.

    Args:
        output_path: Destination path for the generated MP4 file.
        duration_seconds: Length of synthesized video in seconds.
        fps: Frames per second.
        width: Frame width.
        height: Frame height.
        marker_ids: List of marker IDs to include.
        marker_size: Size in pixels of each marker on the canvas.

    Returns:
        Path to the generated video.
    """
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    dictionary = get_aruco_dictionary("DICT_4X4_50")
    total_frames = int(duration_seconds * fps)

    # Pre-generate marker images
    marker_imgs = {}
    for mid in marker_ids:
        raw_m = generate_single_marker(
            dictionary,
            marker_id=mid,
            side_pixels=marker_size,
            border_bits=1,
            margin_pixels=10,
        )
        # Convert to 3-channel BGR
        if len(raw_m.shape) == 2:
            raw_m = cv2.cvtColor(raw_m, cv2.COLOR_GRAY2BGR)
        marker_imgs[mid] = raw_m

    # Try codecs
    codecs = [("mp4v", ".mp4"), ("XVID", ".avi")]
    writer = None
    target_path = output_path

    for c, ext in codecs:
        try:
            target_path = output_path.with_suffix(ext)
            fourcc = cv2.VideoWriter_fourcc(*c)
            w = cv2.VideoWriter(str(target_path), fourcc, fps, (width, height))
            if w.isOpened():
                writer = w
                break
            w.release()
        except Exception:
            continue

    if writer is None:
        raise RuntimeError("Could not initialize VideoWriter for synthetic sample video.")

    print(f"\n[INFO] Generating synthetic ArUco test video: {target_path}")
    print(f"[INFO] Duration: {duration_seconds}s ({total_frames} frames) @ {fps} FPS, {width}x{height}")
    print(f"[INFO] Markers included: IDs {marker_ids}")

    # Generate animation
    for f in range(total_frames):
        # Create a textured or gradient indoor-like background (light gray)
        canvas = np.full((height, width, 3), 235, dtype=np.uint8)

        # Draw grid lines to simulate indoor surface features
        for x in range(0, width, 40):
            cv2.line(canvas, (x, 0), (x, height), (220, 220, 220), 1)
        for y in range(0, height, 40):
            cv2.line(canvas, (0, y), (width, y), (220, 220, 220), 1)

        # Marker 0: Stationary in top-left
        if 0 in marker_imgs:
            m0 = marker_imgs[0]
            mh, mw = m0.shape[:2]
            canvas[50 : 50 + mh, 60 : 60 + mw] = m0

        # Marker 1: Moving horizontally across center
        if 1 in marker_imgs:
            m1 = marker_imgs[1]
            mh, mw = m1.shape[:2]
            # Oscillate horizontally
            offset_x = int(180 + 100 * np.sin(2 * np.pi * f / total_frames))
            pos_y = 200
            canvas[pos_y : pos_y + mh, offset_x : offset_x + mw] = m1

        # Marker 2: Appears only in the second half of the video (simulating entering field of view)
        if 2 in marker_imgs and f >= total_frames // 2:
            m2 = marker_imgs[2]
            mh, mw = m2.shape[:2]
            canvas[300 : 300 + mh, 450 : 450 + mw] = m2

        writer.write(canvas)

    writer.release()
    print(f"[SUCCESS] Synthetic video written successfully -> {target_path.resolve()}\n")
    return target_path


def main():
    parser = argparse.ArgumentParser(
        description="Generate synthetic ArUco marker video for testing",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    parser.add_argument(
        "--output",
        "-o",
        type=str,
        default="data/sample_aruco_video.mp4",
        help="Path for output test video.",
    )
    parser.add_argument(
        "--duration",
        "-d",
        type=float,
        default=3.0,
        help="Video duration in seconds.",
    )
    parser.add_argument(
        "--fps",
        type=float,
        default=30.0,
        help="Frames per second.",
    )
    args = parser.parse_args()

    script_dir = Path(__file__).resolve().parent
    out_path = Path(args.output)
    if not out_path.is_absolute():
        out_path = script_dir / out_path

    create_synthetic_marker_video(
        output_path=out_path,
        duration_seconds=args.duration,
        fps=args.fps,
    )


if __name__ == "__main__":
    main()

