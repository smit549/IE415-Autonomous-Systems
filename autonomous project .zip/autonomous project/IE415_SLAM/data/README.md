# Data Directory (`data/`)

This directory is designated for input video files.

### Placing Recorded Videos:
1. Transfer your recorded indoor video from your smartphone or camera to this folder (e.g., `data/indoor_run_01.mp4`).
2. Supported formats include `.mp4`, `.avi`, `.mov`, `.mkv`.

### Quick Test Without Recording:
You can generate a synthetic test video automatically by running:
```powershell
python create_sample_video.py
```
This produces `data/sample_aruco_video.mp4` containing animated ArUco markers from `DICT_4X4_50`.

