# Visual-Inertial SLAM with Fiducial Landmark Anchors

**Course Project:** IE415 Autonomous Systems / Robotics  
**System Architecture:** Phone-Laptop Hybrid Architecture  
**Current Phase:** Milestone 1 — Laptop-Based Video Loading and ArUco Marker Detection Pipeline

---

## 1. Project Overview

The primary objective of this project is to develop an accurate, drift-resilient **Visual-Inertial SLAM (Simultaneous Localization and Mapping)** system that operates via a Phone-Laptop Hybrid Architecture:

- **Android Smartphone:** Captures high-frame-rate video alongside synchronized internal IMU sensor streams (3-axis accelerometer and 3-axis gyroscope).
- **Laptop (Processing Station):** Executes computer vision pipelines, marker detection, camera intrinsic calibration, Visual-Inertial Odometry (VIO via OpenVINS), and landmark-based pose graph optimization to anchor camera trajectory and eliminate drift.

```
       +---------------------------------------------+
       |             Android Smartphone              |
       |  - Camera Video Recording                   |
       |  - Synchronized IMU (Acc + Gyro)            |
       +----------------------+----------------------+
                              | Data Offload (USB / Wi-Fi)
                              v
       +---------------------------------------------+
       |             Laptop Workstation              |
       |                                             |
       |  [Milestone 1] (Active)                     |
       |  - Video Ingestion & Frame Extraction       |
       |  - ArUco Marker Detection (DICT_4X4_50)     |
       |  - 2D Corner Coordinate Logging (CSV)       |
       |  - Annotated Video Export                   |
       |                                             |
       |  [Milestone 2] (Planned)                    |
       |  - Camera Calibration (Pinhole + Distortion)|
       |  - 3D Marker Pose Estimation (solvePnP)     |
       |                                             |
       |  [Milestone 3 & 4] (Planned)                |
       |  - IMU Preintegration & VIO (OpenVINS)      |
       |  - Landmark Anchor Graph Optimization       |
       +---------------------------------------------+
```

---

## 2. What Milestone 1 Implements

Milestone 1 establishes the initial computer vision and landmark observation pipeline running locally on a Windows workstation:

- **ArUco Marker Generation:** Generates printable, high-contrast ArUco markers using dictionary `DICT_4X4_50` (IDs 0–9).
- **Video Loading & Stream Verification:** Reads pre-recorded video files (e.g., MP4, AVI) or live USB/built-in webcams with resolution and frame-rate preservation.
- **Marker Detection & Identification:** Applies OpenCV's modern `cv2.aruco.ArucoDetector` to detect markers, identify IDs, and extract 4 corner pixel coordinates per marker.
- **Visual Annotation & HUD:** Draws marker borders, IDs, top-left corner orientation indicators, and a real-time Heads-Up Display (HUD) banner.
- **Tabular CSV Logging:** Logs every marker detection into `results/marker_detections.csv` with 11 standardized attributes.
- **Video Export:** Encodes and saves annotated output video to `results/detected_video.mp4`.
- **Summary Statistics:** Reports processed frame count, observation count, and unique marker IDs upon completion.

> **Important Scope Constraint:** Milestone 1 focuses strictly on 2D image-space detection. Camera calibration, 3D pose estimation, smartphone IMU integration, and OpenVINS SLAM are reserved for subsequent milestones.

---

## 3. Software Requirements

- **Operating System:** Windows 10 or Windows 11 (64-bit)
- **Python Version:** Python 3.10, 3.11, or newer
- **Terminal Shell:** Windows PowerShell or Command Prompt
- **IDE:** Visual Studio Code (recommended) or PyCharm
- **Core Dependencies:**
  - `opencv-contrib-python >= 4.8.0.76` (includes ArUco module)
  - `numpy >= 1.24.0`
  - `pandas >= 2.0.0`
  - `pytest >= 7.4.0` (optional, for test runner)

---

## 4. Installation Steps on Windows

### Step 1: Open PowerShell
Open Windows PowerShell and navigate to the project directory:
```powershell
cd "c:\Users\Priyam Vaishnav\Desktop\autonomous project\IE415_SLAM"
```

### Step 2: Create a Python Virtual Environment
Creating an isolated virtual environment prevents library conflicts:
```powershell
python -m venv venv
```

### Step 3: Activate the Virtual Environment
```powershell
.\venv\Scripts\Activate.ps1
```
*(If PowerShell displays a script execution policy error, see Section 12 below).*

### Step 4: Upgrade pip and Install Dependencies
```powershell
python -m pip install --upgrade pip
pip install -r requirements.txt
```

Verify installation:
```powershell
python -c "import cv2, numpy, pandas; print('OpenCV:', cv2.__version__); print('Setup verified successfully!')"
```

---

## 5. Project Directory Structure

```
IE415_SLAM/
│
├── generate_markers.py         # Script to generate ArUco marker PNGs
├── detect_markers.py           # Main video loading & marker detection pipeline
├── create_sample_video.py      # Synthetic test video generator for offline testing
├── requirements.txt            # Python dependencies
├── README.md                   # Project overview and user manual
│
├── markers/                    # Destination directory for generated marker images
│   ├── marker_0.png
│   ├── marker_1.png
│   └── ...
│
├── data/                       # Directory for input video recordings
│   └── sample_aruco_video.mp4  # Generated sample or user-recorded video
│
├── results/                    # Output directory for pipeline results
│   ├── marker_detections.csv   # Structured observation log
│   └── detected_video.mp4      # Annotated output video
│
├── docs/                       # Technical milestone reports
│   └── milestone_1.md          # Milestone 1 technical documentation
│
└── tests/                      # Automated test suite
    ├── __init__.py
    └── test_pipeline.py        # Unit and integration test cases
```

---

## 6. How to Generate ArUco Markers

Run `generate_markers.py` to create the default 10 markers (IDs 0–9):

```powershell
python generate_markers.py
```

### Optional Configuration Arguments:
| Argument | Default | Description |
|---|---|---|
| `--count` | `10` | Number of markers to generate. |
| `--start_id` | `0` | Starting marker ID. |
| `--size` | `400` | Marker width/height in pixels. |
| `--margin` | `20` | Quiet-zone white margin (improves contour detection). |
| `--output_dir`| `markers` | Target output directory. |
| `--add_label` | `False` | Adds a printable text banner displaying ID beneath the marker. |

Example with labels and custom resolution:
```powershell
python generate_markers.py --count 10 --size 500 --add_label
```

---

## 7. How to Place an Input Video in the `data/` Folder

1. Record an indoor video on your smartphone walking past printed ArUco markers.
2. Copy the video file into the `data/` folder (e.g., `data/indoor_walk.mp4`).
3. Alternatively, generate a synthetic sample video immediately by running:
   ```powershell
   python create_sample_video.py
   ```
   This creates `data/sample_aruco_video.mp4` for instant verification without needing a camera.

---

## 8. How to Run Marker Detection

### Basic Usage with Video File:
```powershell
python detect_markers.py --input data/sample_aruco_video.mp4
```

### Useful CLI Flags:
- `--no-display`: Run in headless mode without opening a GUI preview window (ideal for background scripts or automated benchmarks).
- `--no-save-video`: Skip generating the output video and only write the CSV file (runs significantly faster).
- `--csv_output <path>`: Custom destination for the CSV file.
- `--video_output <path>`: Custom destination for the annotated video.

Example running headless with custom output paths:
```powershell
python detect_markers.py --input data/sample_aruco_video.mp4 --no-display --csv_output results/run1.csv
```

To stop playback at any time, press **`Q`** or **`ESC`** in the video display window.

---

## 9. How to Use Webcam Mode

To run live marker detection from your laptop's built-in webcam or an external USB camera:

```powershell
python detect_markers.py --webcam 0
```
- If you have multiple cameras, test device indices `1` or `2`:
  ```powershell
  python detect_markers.py --webcam 1
  ```
- Press **`Q`** in the video window when finished to terminate capture and generate the CSV log and video recording.

---

## 10. Explanation of CSV Columns

The output file `results/marker_detections.csv` logs every individual marker observation per frame. If no markers are present in a frame, no row is written.

| Column Name | Data Type | Description |
|---|---|---|
| `frame_number` | Integer | Zero-indexed frame counter (0, 1, 2, ...). |
| `timestamp_seconds`| Float | Elapsed video time in seconds (`frame_number / fps`), rounded to 4 decimals. |
| `marker_id` | Integer | Unique integer identifier of the detected marker (0 to 49 for `DICT_4X4_50`). |
| `corner_1_x` | Float | Image X coordinate (pixels) of Corner 1 (**Top-Left**). |
| `corner_1_y` | Float | Image Y coordinate (pixels) of Corner 1 (**Top-Left**). |
| `corner_2_x` | Float | Image X coordinate (pixels) of Corner 2 (**Top-Right**). |
| `corner_2_y` | Float | Image Y coordinate (pixels) of Corner 2 (**Top-Right**). |
| `corner_3_x` | Float | Image X coordinate (pixels) of Corner 3 (**Bottom-Right**). |
| `corner_3_y` | Float | Image Y coordinate (pixels) of Corner 3 (**Bottom-Right**). |
| `corner_4_x` | Float | Image X coordinate (pixels) of Corner 4 (**Bottom-Left**). |
| `corner_4_y` | Float | Image Y coordinate (pixels) of Corner 4 (**Bottom-Left**). |

### ArUco Corner Coordinate Diagram:
```
(corner_1_x, corner_1_y) [Top-Left]  o-------------------o  (corner_2_x, corner_2_y) [Top-Right]
                                     |                   |
                                     |   ArUco Marker    |
                                     |     DICT_4X4      |
                                     |                   |
(corner_4_x, corner_4_y) [Btm-Left]  o-------------------o  (corner_3_x, corner_3_y) [Btm-Right]
```

---

## 11. Expected Output Files

Upon successful execution, the following files will be created in `results/`:

1. **`results/marker_detections.csv`**
   - Contains all timestamped 2D observation coordinates.
   - Example preview:
     ```csv
     frame_number,timestamp_seconds,marker_id,corner_1_x,corner_1_y,corner_2_x,corner_2_y,corner_3_x,corner_3_y,corner_4_x,corner_4_y
     0,0.0000,0,60.0,50.0,160.0,50.0,160.0,150.0,60.0,150.0
     0,0.0000,1,180.0,200.0,280.0,200.0,280.0,300.0,180.0,300.0
     1,0.0333,0,60.0,50.0,160.0,50.0,160.0,150.0,60.0,150.0
     ```

2. **`results/detected_video.mp4`**
   - Full resolution, original frame-rate video file with annotated marker contours, ID labels, red orientation dots, and HUD text.

3. **Terminal Console Summary:**
   ```
   =================================================================
     IE415 SLAM - MILESTONE 1 PROCESSING SUMMARY
   =================================================================
     Total frames processed        : 90
     Total marker observations     : 180
     Number of unique marker IDs   : 3
     List of unique detected IDs   : [0, 1, 2]
     Elapsed wall-clock time       : 1.42 seconds
     Average processing speed      : 63.4 FPS
     Output CSV location           : C:\...\results\marker_detections.csv
     Output annotated video location: C:\...\results\detected_video.mp4
   =================================================================
   ```

---

## 12. Common Errors and Solutions

### 1. PowerShell Script Execution Policy Error
**Symptom:** Running `.\venv\Scripts\Activate.ps1` produces:
`File ... cannot be loaded because running scripts is disabled on this system.`  
**Solution:** Enable execution for the current PowerShell session:
```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\venv\Scripts\Activate.ps1
```

### 2. VideoWriter Codec Warning on Windows
**Symptom:** Video is not saved or an OpenCV error mentioning `FOURCC` occurs.  
**Solution:** `detect_markers.py` includes automatic fallback across `mp4v`, `avc1`, `XVID`, and `MJPG`. If your system lacks specific MP4 codecs, install the [K-Lite Codec Pack](https://codecguide.com/) or run with `--no-save-video` to generate the CSV data independently.

### 3. Webcam Cannot Open
**Symptom:** `Failed to open video source: Webcam Device [Index: 0]`.  
**Solution:**
- Check Windows Privacy settings: **Settings > Privacy & Security > Camera** -> Ensure "Let apps access your camera" is **On**.
- Try `--webcam 1` if another application is using camera 0.

### 4. No Markers Detected in Video
**Symptom:** Total observations = 0.  
**Solution:**
- Verify that the printed markers belong to `DICT_4X4_50` (generated by `generate_markers.py`). If you used a different dictionary, pass `--dict <NAME>` to `detect_markers.py`.
- Ensure markers have a visible white border (quiet zone) around the outer black box.
- Avoid motion blur and specular reflections on glossy paper or tape.

---

## 13. Running Automated Tests

To run the automated test suite and verify marker generation, detection logic, CSV schema, and error handling:

```powershell
python -m unittest tests/test_pipeline.py -v
```
or with pytest:
```powershell
pytest -v
```

---

## 14. Academic Roadmap & Future Milestones

| Milestone | Title | Focus Areas |
|---|---|---|
| **Milestone 1** (Current) | **Video Loading & ArUco Detection** | Offline Python pipeline, 2D corner extraction, CSV logging, MP4 annotation. |
| **Milestone 2** | **Camera Calibration & 3D Pose** | Monocular pinhole calibration (`cv2.calibrateCamera`), distortion removal, `cv2.solvePnP` for 3D marker pose $[R \mid t]$. |
| **Milestone 3** | **Android Sensor Acquisition** | Android app recording camera video + high-rate IMU (accelerometer + gyroscope) with microsecond timestamps. |
| **Milestone 4** | **Visual-Inertial SLAM & Anchors** | OpenVINS integration, IMU-camera state estimation, fixed ArUco landmark graph optimization, trajectory evaluation. |

